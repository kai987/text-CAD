# RIVER-R01 / 日本近郊河川デモ / Japanese suburban river demo

这是虚构的日本近郊河流示范段；全部尺寸为演示假设。南北投影180000 mm、场景宽80000 mm、水面18000 mm、水底14000 mm、水深900 mm。桥跨38000 mm、宽4000 mm，步道宽3000 mm。治水、结构承载、基础和法规仍待核定。
架空の日本近郊河川モデルです。すべての寸法はデモ仮定で、治水・構造耐力・基礎・法規は未確認です。
This fictional Japanese suburban river uses demonstration dimensions. Hydraulic capacity, structural strength, foundations and statutory compliance remain unverified.

DXF：可编辑平面与A-A横断面，毫米，A3 1:1000/1:250；模型空间1:1。
STEP：具名毫米实体；GLB：米、Y-up。PNG：实际模型预览、平面及横断面图片。
DXFは編集可能なmm原図、STEPは部材名付きmmソリッド、GLBはm/Y-upです。
DXF drawings retain editable dimensions. STEP contains named millimetre solids; GLB uses metres/Y-up. PNG images show the actual model and drawings.

## 独立生成 / 単独生成 / Standalone generation

在解压目录执行，使用Python 3.11–3.14（本次使用3.13.14）及项目锁定依赖：
展開先でPython 3.11–3.14（今回の検証は3.13.14）と同梱の依存リストを使用します。
From the extracted directory, use Python 3.11–3.14 (verified here with 3.13.14) and the bundled dependency pins:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    CADGEN_DAEMON=0 .venv/bin/python src/river_3d.py
    .venv/bin/python src/generate_river_plans.py
    .venv/bin/python -m unittest discover -s checks -p test_river_geometry.py

参数入口 / パラメーター / Parameters: src/lib/river_geometry.py (RiverParameters / R).
修改参数后，同时重新生成3D与图纸。 / パラメーター変更後は3Dと図面を両方再生成してください。 / Regenerate both the model and drawings after changing parameters.
SVG与DXF日文字体：Arial Unicode MS / Noto Sans JP / 通用字体回退。字体未随包分发。
Japanese annotation fonts are not bundled. DXF viewers may need a Unicode Japanese font.

详见 / 詳細 / Details: docs/river_demo_R01.md。
该文档中的cad_pipeline和网页命令针对完整仓库，本压缩包仅包含独立河流生成文件。
ドキュメント内の全体pipelineとWebコマンドは完全版リポジトリ用です。
The full-catalog pipeline and web commands in that document refer to the complete repository, which is not included in this standalone bundle.
